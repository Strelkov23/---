import json
import sys
import shutil
from pathlib import Path
import monitor as m

if __name__ == "__main__":
    m.init()
    if "--refresh" in sys.argv:
        m.collect_all()
    out=Path("public")
    out.mkdir(exist_ok=True)
    with m.connect() as db:
        articles=[dict(r) for r in db.execute("select a.title,a.url,a.published,a.source,group_concat(t.topic,' · ') as topics from articles a left join topics t on t.article=a.id group by a.id order by a.published desc,a.id desc")]
        (out/"archive.json").write_text(json.dumps(articles,ensure_ascii=False))
        for name,body in [('laws',m.legislation.journal(db)),('sources',m.app({'PATH_INFO':'/sources'},lambda *args:None)[0].decode().split('<main>')[1].split('</main>')[0])]:
            html=Path("shell.html").read_text().replace("<!--BODY-->",body.replace('/archive?', 'index.html?')).replace('src="public.js"','src="public.js"')
            (out/(name+'.html')).write_text(html)
        latest=[dict(r) for r in db.execute("select code,year,value from (select *,row_number() over(partition by code,year order by seen desc) rn from annual) where rn=1 order by year")]
        (out/'stats.json').write_text(json.dumps({'series':m.SERIES,'values':latest},ensure_ascii=False))
    for f in ['sectors.json','style.css','public.js']:
        shutil.copy(f,out/f)
    (out/'index.html').write_text(Path('shell.html').read_text().replace('<!--BODY-->',Path('home.html').read_text()))
