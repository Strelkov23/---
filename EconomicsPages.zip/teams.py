import re
import secrets
from html import escape
from urllib.parse import parse_qs
from datetime import datetime,timezone

def route(db,env,path):
    method=env.get('REQUEST_METHOD','GET')
    if path=='/team' and method=='GET':
        return '200 OK','<h1>Работа отдела</h1><p>Создайте папку для справки. Любой, кому вы передадите секретную ссылку, сможет читать и редактировать её. Сохраните ссылку у себя.</p><form method="post"><button>Создать общую папку</button></form>'
    if method=='POST' and env.get('HTTP_ORIGIN') and env['HTTP_ORIGIN'].split('://')[-1]!=env.get('HTTP_HOST'):
        return '403 Forbidden','Недопустимый источник'
    if path=='/team':
        token=secrets.token_urlsafe(24)
        with db: db.execute("insert into teams values(?,0,'','','','Черновик')",(token,))
        return '201 Created',f'<h1>Папка создана</h1><a href="/team/{token}">Открыть общую папку</a>'
    token=path.split('/')[-1]
    r=db.execute('select * from teams where token=?',(token,)).fetchone()
    if not r:return '404 Not Found','Папка не найдена'
    stages=['Черновик','На согласовании','Согласовано']
    if method=='POST':
        size=int(env.get('CONTENT_LENGTH') or 0)
        if size>128000 or size<0:return '413 Payload Too Large','Слишком большой документ'
        data=parse_qs(env['wsgi.input'].read(size).decode(),keep_blank_values=True)
        val=lambda k:data.get(k,[''])[0]
        if val('stage') not in stages:return '400 Bad Request','Проверьте статус'
        with db:
            changed=db.execute('update teams set rev=rev+1, title=?,owner=?,body=?,stage=? where token=? and rev=?',(val('title'),val('owner'),val('body'),val('stage'),token,val('rev'))).rowcount
            if not changed:return '409 Conflict','Папка изменилась. Вернитесь назад, скопируйте свои изменения и откройте актуальную версию.'
            db.execute('insert into teamlog values(?,?,?,?,?)',(token,r['rev']+1,datetime.now(timezone.utc).isoformat(timespec='minutes'),val('stage'),val('body')))
        r=db.execute('select * from teams where token=?',(token,)).fetchone()
    body=f'<h1>Служебная справка</h1><form method="post"><input type="hidden" name="rev" value="{r["rev"]}">'
    for k,label in [('title','Тема'),('owner','Ответственный')]:
        body+=f'<label>{label}<input name="{k}" value="{escape(r[k],quote=True)}"></label>'
    body+='<label>Статус<select name="stage">'+''.join(f'<option {"selected" if t==r["stage"] else ""}>{t}</option>' for t in stages)+'</select></label>'
    body+=f'<label>Выводы, сроки и ссылки<textarea name="body" rows="10">{escape(r["body"])}</textarea></label><button>Сохранить версию</button></form><h2>История справки</h2>'
    for row in db.execute('select rev,stamp,stage,body from teamlog where token=? order by rev desc',(token,)):
        body+=f'<details><summary>Версия {row[0]} · {row[1]} · {escape(row[2])}</summary><pre>{escape(row[3])}</pre></details>'
    return '200 OK',body
