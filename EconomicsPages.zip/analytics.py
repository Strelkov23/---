from datetime import date, timedelta
from html import escape
from urllib.parse import urlencode
from series import SERIES

def link(path, **args):
    return path+'?'+escape(urlencode(args),quote=True)

def dashboard(db,p):
    try:
        end=date.fromisoformat(p.get('end',date.today().isoformat()))
        days=int(p.get('days','30'))
        if days not in (7,30,90): days=30
        start=end-timedelta(days=days-1)
        prior=start-timedelta(days=days)
    except (ValueError,OverflowError):
        return dashboard(db,{})
    bounds=(str(start),str(end))
    def count(a,b):
        return db.execute('select count(*) from articles where published between ? and ?',(str(a),str(b))).fetchone()[0]
    n=count(start,end)
    old=count(prior,start-timedelta(days=1))
    sources=db.execute('select source,count(*) from articles where published between ? and ? group by source order by 2 desc',bounds).fetchall()
    opts=''.join(f'<option value="{k}" {"selected" if k==days else ""}>{k} дней</option>' for k in (7,30,90))
    body=f'<section class="hero"><p class="kicker">Россия · экономический мониторинг</p><h1>Экономика в данных</h1><form action="/archive"><label>Что вы исследуете?<input type="search" name="q" placeholder="Налоги, кредитование, машиностроение…"></label><button>Искать в архиве</button></form></section><form action="/overview"><label>Период<select name="days">{opts}</select></label><label>По дату<input type="date" name="end" value="{end}"></label><button>Обновить панель</button></form>'
    body+='<div class="cards">'
    for title,value in [('Публикации за период',n),('Изменение к предыдущему периоду',f'{n-old:+d}'),('Источники с публикациями',len(sources))]:
        body+=f'<article><small>{title}</small><strong>{value}</strong></article>'
    body+='</div><article><h2>Публикации по дням</h2><p>Высота столбца показывает число материалов в архиве. Выберите день, чтобы открыть публикации.</p>'
    series=dict(db.execute('select published,count(*) from articles where published between ? and ? group by published',bounds))
    width=days*12
    body+=f'<svg class="plot" viewBox="0 0 {width} 100" aria-label="Динамика числа публикаций">'
    for i in range(days):
        d=str(start+timedelta(days=i)); v=series.get(d,0); height=90*v/max(series.values(),default=1)
        body+=f'<a href="{link("/archive",start=d,end=d)}" aria-label="{d}: {v}"><title>{d}: {v}</title><rect x="{i*12}" y="{99-height}" width="10" height="{max(1,height)}"/></a>'
    body+=f'</svg><small>{start} — {end} · Максимум за день: {max(series.values(),default=0)}</small></article><div class="duo"><article><h2>Темы в архиве</h2>'
    for topic,num in db.execute('select topic,count(*) from topics join articles on article=id where published between ? and ? group by topic order by 2 desc limit 8',bounds):
        body+=f'<p><a href="{link("/archive",sector=topic,start=start,end=end)}">{escape(topic)}</a> · {num}</p>'
    body+='</article><article><h2>Источники за период</h2>'
    for source,num in sources:
        body+=f'<p><a href="{link("/archive",publisher=source,start=start,end=end)}">{escape(source)}</a> · {num}</p>'
    return body+'</article></div><p>Частота публикаций зависит от состава и доступности лент. Один материал может входить в несколько тем.</p>'

def compare(db,p):
    keys=list(SERIES)
    a=p.get('a',keys[0]); b=p.get('b',keys[1])
    if a not in SERIES or b not in SERIES: return compare(db,{})
    body='<p class="kicker">Всемирный банк · Россия</p><h1>Сравнение отраслей</h1><form>'
    for field,chosen,label in [('a',a,'Первая отрасль'),('b',b,'Вторая отрасль')]:
        body+=f'<label>{label}<select name="{field}">'+''.join(f'<option value="{k}" {"selected" if k==chosen else ""}>{v}</option>' for k,v in SERIES.items())+'</select></label>'
    body+='<button>Сравнить</button></form>'
    def read(k):
        return dict(db.execute('select year,value from (select year,value,row_number() over(partition by year order by seen desc) rn from annual where code=?) where rn=1',(k,)))
    x,y=read(a),read(b)
    years=sorted(x.keys()&y.keys())
    if not years: return body+'<p>Пока нет сопоставимых наблюдений. Проверьте загрузку статистики.</p>'
    latest=years[-1]
    body+=f'<article><small>Добавленная стоимость, % ВВП · {latest}</small><h2>{SERIES[a]} — {x[latest]:.2f}% · {SERIES[b]} — {y[latest]:.2f}%</h2><p>Разность первой и второй доли: {x[latest]-y[latest]:+.2f} п. п. Обрабатывающая промышленность входит в промышленность и строительство.</p>'
    peak=max(max(x[t],y[t]) for t in years) or 1
    body+=f'<svg class="plot" viewBox="0 0 600 155" aria-label="Доли в ВВП с {years[0]} по {latest} год"><path d="M4 150H596" stroke="#819590"/>'
    for values,color in [(x,'#087d72'),(y,'#ad5820')]:
        pts=' '.join(f'{4+592*i/max(1,len(years)-1):.1f},{150-145*values[t]/peak:.1f}' for i,t in enumerate(years))
        body+=f'<polyline points="{pts}" fill="none" stroke="{color}" stroke-width="3"/>'
    body+=f'</svg><small>{years[0]} — {latest} · Зелёная линия — первая отрасль, оранжевая — вторая. Шкала 0–{peak:.2f}%.</small></article><table><tr><th>Год</th><th>{SERIES[a]}, %</th><th>{SERIES[b]}, %</th><th>Разность, п. п.</th></tr>'
    for t in reversed(years): body+=f'<tr><td>{t}</td><td>{x[t]:.2f}</td><td>{y[t]:.2f}</td><td>{x[t]-y[t]:+.2f}</td></tr>'
    return body+f'</table><p>Исходные данные: <a href="https://data.worldbank.org/indicator/{a}?locations=RU">{SERIES[a]}</a> · <a href="https://data.worldbank.org/indicator/{b}?locations=RU">{SERIES[b]}</a>.</p>'
