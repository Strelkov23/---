import json
import re
from datetime import datetime, timezone
from html import escape
from urllib.request import urlopen
from urllib.parse import urlencode

SOURCE="Официальное опубликование правовых актов"
FIELDS={"Налоги и взносы":"налог|акциз|страхов.{0,4} взнос","Труд и занятость":"трудов|занятост|заработн|оплат.{0,3} труда|работодател","Бюджет и господдержка":"бюджет|субсиди|грант|государственн.{0,4} поддерж","Банки и финансы":"банк|кредит|валют|финанс|страхован","Закупки и конкуренция":"закуп|контракт|конкуренц|антимонопол","Торговля и таможня":"торгов|тамож|экспорт|импорт","Имущество и бизнес":"предприним|имуществ|кадастр|лиценз|аренд|гражданск.{0,4} кодекс","Промышленность и АПК":"промышлен|энергет|сельск.{0,4} хозяйств|агропром|тариф"}
def setup(db):
    db.executescript("""create table if not exists legal(eo text primary key, day text,title text, first_seen text);
    create table if not exists legal_runs(id integer primary key,stamp text, pages integer, added integer, status text);
    create table if not exists legal_cursor(id integer primary key,eo text);""")
def sync(db,put):
    stamp=datetime.now(timezone.utc).isoformat(timespec="seconds")
    last=db.execute("select eo from legal_cursor where id=1").fetchone()
    anchor=last[0] if last else None
    head=None
    pages=added=0
    try:
        while True:
            page=pages+1
            with urlopen("http://publication.pravo.gov.ru/api/Documents?index="+str(page),timeout=18) as r:
                batch=json.load(r)
            rows=batch["items"]
            if not rows or batch["currentPage"]!=page: raise ValueError("Неполная страница")
            found=False
            with db:
                for doc in rows:
                    eo=doc["eoNumber"]; title=doc["complexName"]; day=doc["publishDateShort"][:10]
                    if not re.fullmatch(r"\d{16}",eo) or not title: raise ValueError("Некорректная карточка")
                    if head is None: head=eo
                    found |= eo==anchor
                    added+=db.execute("insert or ignore into legal values(?,?,?,?)",(eo,day,title,stamp)).rowcount
                    tags=[k for k,v in FIELDS.items() if re.search(v,title,re.I)] or ["Другие правовые акты"]
                    for tag in tags: put(db,title,"https://publication.pravo.gov.ru/document/"+eo,day,SOURCE,tag,stamp)
            pages+=1
            if found or (not anchor and pages>=4) or page>=batch["pagesTotalCount"]:break
        status="Обновление завершено" if anchor else "Первичная загрузка последних страниц"
        with db: db.execute("insert or replace into legal_cursor values(1,?)",(head,))
    except Exception as err: status="Проверка прервана: "+str(err)[:180]
    with db: db.execute("insert into legal_runs(stamp,pages,added,status) values(?,?,?,?)",(stamp,pages,added,status))
def journal(db):
    runs=db.execute("select * from legal_runs order by id desc limit 12").fetchall()
    body='<p class="kicker">Официальные публикации РФ</p><h1>Правовой мониторинг</h1><p>Сборщик сохраняет карточки федеральных и региональных актов, в том числе без тематической метки. Тема определяется по заголовку. Даты действия отдельных норм требуют проверки по тексту документа.</p>'
    for label in ["Все публикации",*FIELDS,"Другие правовые акты"]:
        args={"publisher":SOURCE}
        if label!="Все публикации":args["sector"]=label
        body+=f'<a class="chip" href="/archive?{escape(urlencode(args))}">{label}</a> '
    body+='<h2>История проверок</h2><table><tr><th>Время UTC</th><th>Страниц</th><th>Новых актов</th><th>Результат</th></tr>'
    for r in runs: body+=f'<tr><td>{escape(r["stamp"])}</td><td>{r["pages"]}</td><td>{r["added"]}</td><td>{escape(r["status"])}</td></tr>'
    return body+'</table><h2>Последние документы</h2>'+''.join(f'<article><small>Опубликован {escape(d)} · № {eo}</small><h2><a href="https://publication.pravo.gov.ru/document/{eo}">{escape(t)}</a></h2><small>Вступление в силу: требуется проверка текста</small></article>' for eo,d,t in db.execute('select eo,day,title from legal order by day desc,eo desc limit 15'))
