const el=id=>document.getElementById(id);
const node=(tag,text)=>Object.assign(document.createElement(tag),{textContent:text});
const fmt=v=>v.toLocaleString('ru',{maximumFractionDigits:2});
async function load(file){const r=await fetch(file);if(!r.ok)throw Error();return r.json()}
async function archive(){
 const rows=await load('archive.json'), params=new URLSearchParams(location.search);
 for(const [id,values] of [['publisher',rows.map(r=>r.source)],['sector',rows.flatMap(r=>(r.topics||'').split(' · '))]]){
  el(id).add(new Option('Все',''));for(const v of [...new Set(values.filter(Boolean))].sort())el(id).add(new Option(v,v));
  el(id).value=params.get(id)||'';
 }
 el('q').value=params.get('q')||'';
 let limit=20;
 function draw(){
  const words=el('q').value.toLocaleLowerCase('ru').trim().split(/\s+/);
  const matches=rows.filter(r=>(!el('publisher').value||r.source===el('publisher').value)&&(!el('sector').value||(r.topics||'').split(' · ').includes(el('sector').value))&&words.every(w=>[r.title,r.source,r.topics].join(' ').toLocaleLowerCase('ru').includes(w)));
  el('count').textContent='Найдено: '+fmt(matches.length);el('list').replaceChildren();
  for(const r of matches.slice(0,limit)){const card=node('article',''),a=node('a',r.title);a.href=r.url;card.append(node('small',[r.published,r.source].filter(Boolean).join(' · ')),node('h2',''));card.lastChild.append(a);el('list').append(card)}
  el('more').hidden=matches.length<=limit;
 }
 el('filters').oninput=()=>{limit=20;draw()};el('filters').onsubmit=e=>e.preventDefault();el('more').onclick=()=>{limit+=40;draw()};draw();
}
async function stats(){
 const d=await load('stats.json');
 for(const id of ['first','second'])for(const [key,label] of Object.entries(d.series))el(id).add(new Option(label,key));
 el('second').selectedIndex=1;
 function draw(){
  const series=id=>new Map(d.values.filter(r=>r.code===el(id).value).map(r=>[r.year,r.value]));
  const a=series('first'),b=series('second');el('chart').replaceChildren();
  for(const year of [...a.keys()].filter(y=>b.has(y)).slice(-10).reverse()){
   const row=node('p',year+' · '+fmt(a.get(year))+'% / '+fmt(b.get(year))+'%');
   for(const value of [a.get(year),b.get(year)]){row.append(node('br',''),Object.assign(node('meter',''),{min:0,max:100,value}))}
   el('chart').append(row);
  }
 }
 el('first').onchange=el('second').onchange=draw;draw();
}
async function model(){
 const m=await load('sectors.json');m.names.forEach((s,i)=>el('industry').add(new Option(s,i)));el('industry').value='8';
 function draw(){el('effects').replaceChildren();if(!el('shock').value||!el('shock').validity.valid){el('effect').textContent='Укажите изменение от −20 до 20%';return}
 const v=m.effects.map(r=>r[+el('industry').value]*Number(el('shock').value)/100000);
 el('effect').textContent='Изменение валового выпуска: '+fmt(v.reduce((a,b)=>a+b,0))+' млрд ₽';
 v.forEach((n,i)=>el('effects').append(node('p',m.names[i]+' · '+fmt(n)+' млрд ₽')))}
 el('industry').onchange=el('shock').oninput=draw;draw();
}
if(el('filters'))for(const [fn,id] of [[archive,'count'],[model,'effect'],[stats,'chart']])fn().catch(()=>el(id).textContent='Не удалось загрузить данные. Обновите страницу.');
